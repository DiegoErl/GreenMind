<?php
const BASE_URL = "http://localhost/Galeria-Pinturas/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda_galeria";
const CHARSET = "charset=utf8";
const TITLE = "Green Mind";
const MONEDA = "MXN";
const CLIENT_ID = "AaT-y-_U9D7g3YU6OuNexquQf7FkIPmLbERIAVaaupoNKy6iDFEExDaDxjvfrHU_afaoz3SRx6CL_NxM";
const USER_SMTP = "diegoprueba90@gmail.com";
const PASS_SMTP = "eccqatpjkvebxgzj";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>