<?php include_once 'Views/template/header-principal.php'; ?>



    <!-- Start Banner Hero -->
    <div id="template-mo-zay-hero-carousel" class="carousel slide" data-bs-ride="carousel">
        <ol class="carousel-indicators">
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#template-mo-zay-hero-carousel" data-bs-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/images/Carrusel/C1.png" alt="" width="400">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left align-self-center">
                                <h1 class="h1 text-success"><b>Calidad</b> y <b>Durabilidad Garantizadas</b></h1>
                                <h3 class="h2">Productos diseñados para durar y rendir al máximo</h3>
                                <p>
                                Ofrecemos herramientas diseñadas para resistir el trabajo duro. Equipos confiables para garantizar que tu proyecto avance sin interrupciones. 
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/images/Carrusel/C2.png" alt="" width="350">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
                                <h1 class="h1 text-success"><b>Fertilizantes Orgánicos Certificados</b></h1>
                                <h3 class="h2">Cultiva de manera sostenible con soluciones ecológicas</h3>
                                <p>
                                Nutre tus cultivos con fertilizantes orgánicos de alta calidad.   
                                <strong>Aumenta la productividad</strong> de manera sostenible y protege el medio ambiente.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="container">
                    <div class="row p-5">
                        <div class="mx-auto col-md-8 col-lg-6 order-lg-last">
                            <img class="img-fluid" src="./assets/images/Carrusel/C3.png" alt="">
                        </div>
                        <div class="col-lg-6 mb-0 d-flex align-items-center">
                            <div class="text-align-left">
                                <h1 class="h1 text-success"> <b>Semillas de Alta Calidad para una Cosecha Superior</b> </h1>
                                <h3 class="h2">Variedades adaptadas a tus necesidades y a tu clima </h3>
                                <p>
                                Garantiza una cosecha robusta y saludable con nuestras semillas certificadas. Variedades resistentes y adaptadas a tus necesidades.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev text-decoration-none w-auto ps-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="prev">
            <i class="fas fa-chevron-left"></i>
        </a>
        <a class="carousel-control-next text-decoration-none w-auto pe-3" href="#template-mo-zay-hero-carousel" role="button" data-bs-slide="next">
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>
    <!-- End Banner Hero -->


    <!-- Start Categories of The Month -->
    <section class="container py-5">
        <div class="row text-center pt-3">
            <div class="col-lg-6 m-auto">
                <h1 class="h1">Categorias</h1>
                <p>
                Encuentra todo lo que necesitas para optimizar tu producción agrícola
                </p>
            </div>
        </div>
        <div class="row">
            <?php foreach ($data['categorias'] as $categoria) { ?>

            <div class="col-12 col-md-2 p-5 mt-3">
                <a href="<?php echo BASE_URL . 'principal/categorias/' . $categoria['id']; ?>"><img src="<?php echo $categoria['imagen']; ?>" class="rounded-circle img-fluid border"></a>
                <h5 class="text-center mt-3 mb-3"> <?php echo $categoria['categoria']; ?> </h5>
                <p class="text-center"><a class="btn btn-success">Comprar</a></p>
            </div>
            
            <?php } ?>
        </div>
    </section>
    <!-- End Categories of The Month -->


    <!-- Start Featured Product -->
    <section class="bg-light">
        <div class="container py-5">
            <div class="row text-center py-3">
                <div class="col-lg-6 m-auto">
                    <h1 class="h1">Productos nuevos</h1>
                    <p>
                    Descubre nuestros productos más recientes, diseñados para mejorar la calidad de tu producción.
                    </p>
                </div>
            </div>
            <div class="row">
                <?php foreach ($data ['nuevoProductos'] as $producto) { ?>
                <div class="col-12 col-md-4 mb-4">
                    <div class="card h-100">
                        <a href="<?php echo BASE_URL . 'principal/detail/' . $producto['id']; ?>">
                            <img src="<?php echo $producto['imagen'] ; ?>" class="card-img-top" alt="<?php echo $producto['nombre'] ; ?>">
                        </a>
                        <div class="card-body">
                            <ul class="list-unstyled d-flex justify-content-between">
                                <li>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-warning fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                    <i class="text-muted fa fa-star"></i>
                                </li>
                                <li class="text-muted text-right"> <?php echo MONEDA . ' ' . $producto['precio'] ; ?></li>
                            </ul>
                            <a href="<?php echo BASE_URL . 'principal/detail/' . $producto['id']; ?>" class="h2 text-decoration-none text-dark"> <?php echo $producto['nombre'] ; ?> </a>
                            <p class="card-text">
                                  <?php echo $producto['descripcion'] ; ?>
                            </p>
                            <p class="text-muted">Reviews (24)</p>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- End Featured Product -->
<!-- Menú de Accesibilidad -->
<div class="accessibility-menu" style="position: fixed; top: 10px; right: 10px; background: white; padding: 10px; border: 1px solid #ccc; z-index: 1000;">
    <button onclick="changeFontSize('increase')">Aumentar Texto</button>
    <button onclick="changeFontSize('decrease')">Disminuir Texto</button>
    <button onclick="toggleGrayscale()">Escala de Grises</button>
    <button onclick="toggleHighContrast()">Alto Contraste</button>
    <button onclick="resetAccessibility()">Restablecer</button>
</div>

<script>
    let highContrastEnabled = false;
    let grayscaleEnabled = false;

    function changeFontSize(action) {
        const body = document.body;
        if (action === 'increase') {
            body.style.fontSize = '1.2em'; // Aumentar texto
        } else if (action === 'decrease') {
            body.style.fontSize = '0.8em'; // Disminuir texto
        }
    }

    function toggleGrayscale() {
        const body = document.body;
        grayscaleEnabled = !grayscaleEnabled;
        body.style.filter = grayscaleEnabled ? 'grayscale(100%)' : 'none';
    }

    function toggleHighContrast() {
        const body = document.body;
        highContrastEnabled = !highContrastEnabled;
        body.style.backgroundColor = highContrastEnabled ? 'black' : 'white';
        body.style.color = highContrastEnabled ? 'white' : 'black';
    }

    function resetAccessibility() {
        const body = document.body;
        body.style.fontSize = '1em'; // Restablecer tamaño de texto
        body.style.filter = 'none'; // Restablecer escala de grises
        body.style.backgroundColor = 'white'; // Restablecer color de fondo
        body.style.color = 'black'; // Restablecer color de texto
        highContrastEnabled = false;
        grayscaleEnabled = false;
    }
</script>


    
    <!-- bot de ayuda-->
    <script SameSite="None; Secure" src="https://cdn.landbot.io/landbot-3/landbot-3.0.0.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var myLandbot = new Landbot.Popup({
            configUrl: 'https://storage.googleapis.com/landbot.site/v3/H-2643729-DX4SWKLNPCI7UXXY/index.json',
        });

        document.querySelector('.chatbot-icon').addEventListener('click', function() {
            myLandbot.open(); 
        });
    });
</script>

    

<?php include_once 'Views/template/footer-principal.php'; ?>


   
</body>

</html>